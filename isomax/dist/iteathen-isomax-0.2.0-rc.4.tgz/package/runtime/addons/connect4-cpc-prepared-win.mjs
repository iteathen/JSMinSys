import {firstSetBitIndex32} from '../src/word32.mjs';

// COLD: geometry-only response eligibility and cell access plans. Scratch is
// worker-local and reused; the certificate never recursively invokes itself.
export function prepareConnect4CpcWin32(g){
  const responseCount=new Uint8Array(g.shapeCount),guaranteeCandidate=new Uint8Array(g.shapeCount),
    responseColumns=new Uint32Array(g.shapeCount*4),responseRows=new Uint32Array(g.shapeCount*4),
    partner=new Int32Array(g.columns);
  for(let id=0;id<g.shapeCount;id+=1){
    const base=id*4,size=g.shapeSize[id];let count=0;
    for(let j=0;j<size;j+=1){
      const cell=g.shapeCells[base+j],row=g.cellRow[cell];
      if((row^g.rows)&1){responseColumns[base+count]=g.cellColumn[cell];responseRows[base+count]=row;count+=1;}
    }
    responseCount[id]=count;guaranteeCandidate[id]=count===size?1:0;
  }
  return {g,responseCount,guaranteeCandidate,responseColumns,responseRows,partner};
}

// Same guarded, win-only whole-reservoir certificate as the inherited routine.
// A zero is UNRESOLVED, never a draw/loss classification. No NDC inference.
export function evaluateConnect4PreparedCpcWin32(p,words,offset,basis,basisOffset,basisSize,controller){
  const g=p.g,meta=words[offset+g.metaOffset];
  if((meta&3)||controller===((meta>>>2)&1)||((g.cellCount-(meta>>>2))&1))return 0;
  const own=offset+(controller?g.p1Offset:g.p0Offset),
    opponent=offset+(controller?g.p0Offset:g.p1Offset),coordinateWords=g.coordWords,
    candidate=p.guaranteeCandidate,responseCount=p.responseCount,
    responseColumns=p.responseColumns,responseRows=p.responseRows;
  let guaranteed=0;
  for(let word=0;word<coordinateWords&&!guaranteed;word+=1){
    let bits=words[own+word]>>>0;const indexBase=word<<5;
    while(bits){
      const i=indexBase+firstSetBitIndex32(bits);if(i>=basisSize)break;
      const id=basis[basisOffset+i];
      if(candidate[id]){
        const base=id*4,count=responseCount[id];let all=1;
        for(let j=0;j<count;j+=1){
          const at=base+j;
          if(responseRows[at]<=words[offset+responseColumns[at]]){all=0;break;}
        }
        if(all){guaranteed=1;break;}
      }
      bits=(bits&(bits-1))>>>0;
    }
  }
  if(!guaranteed)return 0;

  // Pair odd live frontiers once, instead of rebuilding the same pairing for
  // every unblocked opponent residual. Even columns get no frontier partner.
  const partner=p.partner,columns=g.columns,rows=g.rows,
    shapeCells=g.shapeCells,shapeSize=g.shapeSize,cellRow=g.cellRow,cellColumn=g.cellColumn;
  let pending=-1;
  for(let c=0;c<columns;c+=1){
    partner[c]=-1;
    if((rows-words[offset+c])&1){
      if(pending<0)pending=c;
      else {partner[c]=pending;partner[pending]=c;pending=-1;}
    }
  }
  for(let word=0;word<coordinateWords;word+=1){
    let bits=words[opponent+word]>>>0;const indexBase=word<<5;
    while(bits){
      const i=indexBase+firstSetBitIndex32(bits);if(i>=basisSize)break;
      const id=basis[basisOffset+i],base=id*4,count=responseCount[id];let blocked=0;
      for(let j=0;j<count;j+=1){
        const at=base+j;
        if(responseRows[at]>words[offset+responseColumns[at]]){blocked=1;break;}
      }
      if(!blocked){
        const size=shapeSize[id];
        for(let j=0;j<size&&!blocked;j+=1){
          const cell=shapeCells[base+j],column=cellColumn[cell],mate=partner[column];
          if(mate<0||cellRow[cell]!==words[offset+column])continue;
          for(let k=j+1;k<size;k+=1){
            const other=shapeCells[base+k];
            if(cellColumn[other]===mate&&cellRow[other]===words[offset+mate]){blocked=1;break;}
          }
        }
      }
      if(!blocked)return 0;
      bits=(bits&(bits-1))>>>0;
    }
  }
  return 1;
}
